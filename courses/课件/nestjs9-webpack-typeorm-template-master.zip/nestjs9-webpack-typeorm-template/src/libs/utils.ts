import * as path from 'path';

export const resolve = (dir) => path.join(path.resolve(__dirname, '../../'), dir)